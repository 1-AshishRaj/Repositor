

```python
## import the package

import numpy as np
```


```python
## Step:0
## Assigning a input value to variabe eip

eip=np.array([[1,0,1,0],[1,0,1,1],[0,1,0,1]])

print(eip)
```

    [[1 0 1 0]
     [1 0 1 1]
     [0 1 0 1]]
    


```python
#Assigning the target values to varialbe mlblr

mlblr=np.array([[1],[1],[0]])

print(mlblr)
```

    [[1]
     [1]
     [0]]
    


```python
##Step :1
## Initialize weights and biases with random values

eip_wts=np.array([[0.42,0.88,0.55],[0.10,0.73,0.68],[0.60,0.18,0.47],[0.92,0.11,0.52]])

eip_bias=np.array([[0.46,0.72,0.08]])


print(eip_wts)

print(eip_bias)
```

    [[ 0.42  0.88  0.55]
     [ 0.1   0.73  0.68]
     [ 0.6   0.18  0.47]
     [ 0.92  0.11  0.52]]
    [[ 0.46  0.72  0.08]]
    


```python
## Step 2:

##Calculate hidden layer input:

eip_hidden= np.dot(eip,eip_wts)+eip_bias

print(eip_hidden)

```

    [[ 1.48  1.78  1.1 ]
     [ 2.4   1.89  1.62]
     [ 1.48  1.56  1.28]]
    


```python
### Definin the sigmoid function

def sigmoid(x):
    return 1/(1+np.exp(-x))
```


```python
##Step 3:

## Non LInerity transformation on hidden layer input

eip_activation= sigmoid(eip_hidden)

print(np.round(eip_activation,2))


```

    [[ 0.81  0.86  0.75]
     [ 0.92  0.87  0.83]
     [ 0.81  0.83  0.78]]
    


```python
## Intializong the wts and bias

mlblr_wts=np.array([[0.30,0,0],[0.25,0,0],[0.23,0,0]])
mlblr_bias=np.array([0.69])


print(mlblr_wts)

print(mlblr_bias)

```

    [[ 0.3   0.    0.  ]
     [ 0.25  0.    0.  ]
     [ 0.23  0.    0.  ]]
    [ 0.69]
    


```python
## Step 4:

##Perform linear and non-linear transformation of hidden layer activation at output layer

mlblr_ot= np.dot(eip_activation,mlblr_wts)+ mlblr_bias

mlblr_output=sigmoid(mlblr_ot)

print(mlblr_output)

```

    [[ 0.78932406  0.66596693  0.66596693]
     [ 0.79806432  0.66596693  0.66596693]
     [ 0.78933532  0.66596693  0.66596693]]
    


```python
## Step 5:

##Calculate gradient of Error(E) at output layer

eip_error= mlblr- mlblr_output

print(eip_error)
```

    [[ 0.21067594  0.33403307  0.33403307]
     [ 0.20193568  0.33403307  0.33403307]
     [-0.78933532 -0.66596693 -0.66596693]]
    


```python
## Defining the derivative function

def derivatives(x):
    return x*(1-x)

```


```python
## Step 6:

## Compute slope at output and hidden layer

mlblr_slope_output = derivatives(mlblr_output)
mlblr_slope_hidden = derivatives(eip_activation)

print(mlblr_slope_output)

print(mlblr_slope_hidden)
```

    [[ 0.16629159  0.22245498  0.22245498]
     [ 0.16115766  0.22245498  0.22245498]
     [ 0.16628507  0.22245498  0.22245498]]
    [[ 0.15104409  0.12347974  0.18736988]
     [ 0.076255    0.11401936  0.13791222]
     [ 0.15104409  0.14349349  0.17022212]]
    


```python
## Step 7:

## Compute delta at output layer

eip_delta_output= eip_error*mlblr_slope_output

print(eip_delta)
```

    [[ 0.03503364  0.05383199  0.05554471]
     [ 0.03358021  0.05383199  0.05554471]
     [-0.13125983 -0.10732567 -0.11074036]]
    


```python
## Step 8: 
## Calculate Error at hidden layer


eip_error_hidden=np.dot(eip_delta_output,mlblr_wts.T)

print(eip_error_hidden)
```

    [[ 0.01051009  0.00875841  0.00805774]
     [ 0.00976304  0.00813587  0.007485  ]
     [-0.0393764  -0.03281367 -0.03018858]]
    


```python
##Step 9: 

## Compute delta at hidden layer

d_hiddenlayer = Error_at_hidden_layer * slope_hidden_layer


eip_delta_hidden= eip_error_hidden * mlblr_slope_hidden

print(eip_delta_hidden)
```

    [[ 0.00158749  0.00108149  0.00150978]
     [ 0.00074448  0.00092765  0.00103227]
     [-0.00594757 -0.00470855 -0.00513876]]
    


```python
##learning rate

lr=1
## Step 10:

#### Update weight at both output and hidden layer 

mlblr_wts=mlblr_wts +np.dot(eip_activation.T,eip_delta) *lr

print(mlblr_wts)
```

    [[ 0.25240403  0.00578015  0.00596405]
     [ 0.20068417  0.00414177  0.00427355]
     [ 0.18161271  0.00134973  0.00139267]]
    


```python
##Step 10(a): 

## Update weight at both output and hidden layer

eip_wts=eip_wts+np.dot(eip.T,eip_delta_hidden)*lr


print(eip_wts)
```

    [[ 0.42233197  0.88200913  0.55254205]
     [ 0.09405243  0.72529145  0.67486124]
     [ 0.60233197  0.18200913  0.47254205]
     [ 0.91479691  0.1062191   0.51589351]]
    


```python
##Step 11:

## Update weight at both output and hidden layer

eip_bias=eip_bias+np.sum(eip_delta_hidden,axis=0)*lr

print(eip_bias)
```

    [[ 0.45638439  0.71730058  0.07740329]]
    


```python
##Step 11:

## Update weight at both output and hidden layer

mlblr_bias=mlblr_bias + np.sum(eip_delta_output, axis=0) *lr

print(mlblr_bias)
```

    [ 0.56264488  0.69093396  0.69093396]
    

#### Back propagation With Random values


```python
x=np.array([[1,0,1,0],[1,0,1,1],[0,1,0,1]])
```


```python
y=np.array([[1],[1],[0]])
```


```python
inputlayer_neurons = x.shape[1] 
hiddenlayer_neurons = 3 
output_neurons = 1 
```


```python
wh=np.random.uniform(size=(inputlayer_neurons,hiddenlayer_neurons))

bh=np.random.uniform(size=(1,hiddenlayer_neurons))

wout=np.random.uniform(size=(hiddenlayer_neurons,output_neurons))

bout=np.random.uniform(size=(1,output_neurons))
```


```python
hidden_layer_input1=np.dot(x,wh)

hidden_layer_input=hidden_layer_input1 + bh

hiddenlayer_activations = sigmoid(hidden_layer_input)

output_layer_input1=np.dot(hiddenlayer_activations,wout)

output_layer_input= output_layer_input1+ bout

output = sigmoid(output_layer_input)
```


```python
E = y-output
slope_output_layer = derivatives(output)

slope_hidden_layer = derivatives(hiddenlayer_activations)

d_output = E * slope_output_layer

Error_at_hidden_layer = d_output.dot(wout.T)

d_hiddenlayer = Error_at_hidden_layer * slope_hidden_layer

wout += hiddenlayer_activations.T.dot(d_output) 

bout += np.sum(d_output, axis=0,keepdims=True) 

wh += x.T.dot(d_hiddenlayer)
bh += np.sum(d_hiddenlayer, axis=0,keepdims=True) 

```


```python
print(output)
```

    [[ 0.78769876]
     [ 0.79032853]
     [ 0.77784412]]
    


```python

```
